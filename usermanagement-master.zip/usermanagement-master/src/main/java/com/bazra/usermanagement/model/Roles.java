package com.bazra.usermanagement.model;
/**
 * Roles to be assigned
 * @author MOSS
 *
 */
public enum Roles {
	USER,
	AGENT,
	AGENT_MASTER,
	MERCHANT,
	ADMIN;

    

}
